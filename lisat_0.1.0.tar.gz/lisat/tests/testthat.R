library(testthat)
library(lisat)
testthat::test_check("lisat")